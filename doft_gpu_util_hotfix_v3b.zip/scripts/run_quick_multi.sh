#!/usr/bin/env bash
set -euo pipefail
OUTDIR="${1:-runs/quick_gpu}"
PAR="${PAR:-4}"
echo "# Lanzando $PAR shards → $OUTDIR.{0..$((PAR-1))}"
pids=()
for i in $(seq 0 $((PAR-1))); do
  SUF="${OUTDIR}_shard${i}"
  SEED_OFF=$((i*1000))
  echo ">> shard $i  →  $SUF  (SEED_OFFSET=${SEED_OFF})"
  SEED_OFFSET=${SEED_OFF} USE_GPU=${USE_GPU:-1} bash scripts/run_quick.sh "$SUF" &
  pids+=($!)
done
ec=0
for pid in "${pids[@]}"; do
  if ! wait "$pid"; then ec=1; fi
done
exit $ec
