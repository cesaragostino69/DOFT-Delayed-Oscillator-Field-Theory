#!/usr/bin/env python3
import argparse, pathlib
import pandas as pd

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="carpetas shard: runs/quick_gpu_shard*")
    ap.add_argument("--out", required=True, help="carpeta de salida")
    args = ap.parse_args()

    out = pathlib.Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    dfs_full, dfs_sum = [], []
    for p in args.inputs:
        p = pathlib.Path(p)
        tf = p/"table_full.csv"
        sm = p/"summary.csv"
        if tf.exists():
            df = pd.read_csv(tf)
            df["shard"] = p.name
            dfs_full.append(df)
        if sm.exists():
            ds = pd.read_csv(sm)
            ds["shard"] = p.name
            dfs_sum.append(ds)

    if dfs_full:
        big = pd.concat(dfs_full, ignore_index=True)
        big.to_csv(out/"table_full.csv", index=False)
        summary = (big.groupby(["gamma","xi"], as_index=False)
                     .agg(ceff_bar=("ceff_bar","mean"),
                          anisotropy_rel=("anisotropy_rel","mean"),
                          hbar_eff=("hbar_eff","mean"),
                          lpc_viol_frac=("lpc_viol_frac","mean"),
                          lpc_ok_frac=("lpc_ok_frac","mean"),
                          runs=("seed","count")))
        summary.to_csv(out/"summary.csv", index=False)

    if dfs_sum:
        all_summaries = pd.concat(dfs_sum, ignore_index=True)
        all_summaries.to_csv(out/"summary_by_shard.csv", index=False)

if __name__ == "__main__":
    main()